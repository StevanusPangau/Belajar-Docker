# Untuk melihat status container kita bisa menggunakan perintah
docker container stats

# atau jika ingin melihat stats container tertentu bisa lihat dengan menggunakan perintah
# docker container stats namaContainer
docker container stats contohnginx