# Melihat Log dari container
# docker container logs containerId/namacontainer
docker container logs contohredis

# Melihat log secara realtime
# docker container logs -f containerId/namacontainer
docker container logs -f contohredis