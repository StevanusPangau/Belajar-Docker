# masuk kedalam container
# docker container exec -i -t containerId/containerName /bin/bash
docker container exec -i -t contohredis /bin/bash

# untuk keluar dari exec container
exit