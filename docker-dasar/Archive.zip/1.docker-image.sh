# Melihat list image yang ada di docker
docker image ls

# Menginstall image di docker
# docker image pull namaimage:tag
docker image pull redis:latest

# Menghapus image di docker
# docker image rm namaimage:tag
docker image rm redis:latest